//variáveis da bolinha
let xBolinha = 300;
let yBolinha = 200;
let diametro = 13;
let raio = diametro / 2;

//variáveis da raquete
let xRaquete = 5;
let yRaquete = 150;
let larguraRaquete = 10;
let comprimentoRaquete = 90;

//variáveis do oponente
let xOponente = 585;
let yOponente = 150;
let velocidadeYOponente;

let coetxRa= false;

//placar do jogo
let meusPontos = 0
let pontosOponente = 0

//sons do jogo
let raquetada;
let ponto;
let trilha;

//velocidade da bolinha
let velocidadeXBolinha = 6;
let velocidadeYBolinha = 6;

function preload(){
  trilha = loadSound("trilha.mp3");
  ponto = loadSound("ponto.mp3");
  raquetada = loadSound("raquetada.mp3");
}

function setup() {
  createCanvas(600, 400);
  trilha.loop();
}

function draw() {
  background(0);
  mostraCampo();
  mostraBolinha();
  movimentaBolinha();
  verificaColisaoBorda();
  mostraRaquete(xRaquete, yRaquete);
  mostraRaquete(xOponente, yOponente);
  movimentaMinhaRaquete();
  movimentaOponente();
  verificaColisaoRaquete(xRaquete, yRaquete);
  verificaColisaoRaquete(xOponente, yOponente);
  incluiPlacar();
  marcaPonto();
  bolinhaNaoFicaPresa();
}

function mostraBolinha(){
  circle(xBolinha, yBolinha, diametro);
}

function movimentaBolinha(){
  xBolinha += velocidadeXBolinha
  yBolinha += velocidadeYBolinha
}

function verificaColisaoBorda(){
  if (xBolinha + raio > width || xBolinha - raio <0){velocidadeXBolinha *= -1}
  if (yBolinha + raio > height || yBolinha -raio <0){velocidadeYBolinha *= -1}
}

function mostraRaquete(x,y){
    rect(x, y, larguraRaquete, comprimentoRaquete);
}

function movimentaMinhaRaquete(){
  if (keyIsDown(UP_ARROW)){
    yRaquete -= 10;
  }
  if (keyIsDown(DOWN_ARROW)){
    yRaquete += 10;
  }
}

function verificaColisaoRaquete (x, y){
     colidiu = collideRectCircle(x, y, larguraRaquete, comprimentoRaquete, xBolinha, yBolinha, raio);
  if (colidiu){
    velocidadeXBolinha *= -1;
    raquetada.play();
  }
}

function movimentaOponente(){
  if (keyIsDown(87)){
    yOponente -= 10;
  }
  if (keyIsDown(83)){
    yOponente += 10;
  }
}

// function movimentaOponente(){
//   velocidadeYOponente = yBolinha - yOponente - comprimentoRaquete / 2 - 30;
//   yOponente += velocidadeYOponente
// }

function incluiPlacar(){
  stroke(color(255))
  textAlign(CENTER)
  textSize(16)
  fill(color(255,140,0))
  rect(130,10,40,20)
  fill(255)
  text(meusPontos, 150, 26)
  fill(color(255,140,0))
  rect(430,10,40,20)
  fill(255)
  text(pontosOponente, 450,26)
}

function mostraCampo(){
  line(300,0,300,400)
  fill(255)
}

function marcaPonto(){
  if (xBolinha > 590){
    meusPontos += 1;
    ponto.play();
  }
  if (xBolinha < 10){
    pontosOponente += 1;
    ponto.play();
  }
}

function bolinhaNaoFicaPresa(){
    if (xBolinha + raio < 0){
    console.log('bolinha ficou presa');
    xBolinha = 300;
    }
}